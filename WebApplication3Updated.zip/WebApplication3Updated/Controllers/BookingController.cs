﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using WebApplication3Updated.Models;
using WebApplication3Updated.ViewModel;

namespace WebApplication3Updated.Controllers
{
    public class BookingController : Controller
    {
        private readonly MTLDBEntities1 objMTLDBEntities1;

        public BookingController()
        {
            objMTLDBEntities1 = new MTLDBEntities1();
        }

        public ActionResult Index()
        {
            var objBookingViewModel = new BookingViewModel
            {
                ListOfRooms = (from objRoom in objMTLDBEntities1.Rooms
                               where objRoom.BookingStatusId == 2
                               select new SelectListItem
                               {
                                   Text = objRoom.RoomNumber.ToString(),
                                   Value = objRoom.RoomId.ToString()
                               }).ToList(),
                BookingFrom = DateTime.Now,
                BookingTo = DateTime.Now.AddDays(1)
            };

            return View(objBookingViewModel);
        }

        [HttpPost]
        public JsonResult Index(BookingViewModel objBookingViewModel)
        {
            if (objBookingViewModel == null)
            {
                return Json(new { message = "Invalid booking data.", success = false }, JsonRequestBehavior.AllowGet);
            }

            try
            {
                DateTime bookingFrom = objBookingViewModel.BookingFrom;
                DateTime bookingTo = objBookingViewModel.BookingTo;
                double numberOfDays = (bookingTo - bookingFrom).TotalDays;

                var objRoom = objMTLDBEntities1.Rooms.SingleOrDefault(model => model.RoomId == objBookingViewModel.AssignRoomId);
                if (objRoom == null)
                {
                    return Json(new { message = "Room not found.", success = false }, JsonRequestBehavior.AllowGet);
                }

                decimal roomPrice = objRoom.RoomPrice;
                decimal totalPrice = roomPrice * (decimal)numberOfDays;

                var roomBooking = new RoomBooking
                {
                    BookingFrom = bookingFrom,
                    BookingTo = bookingTo,
                    AssignRoomId = objBookingViewModel.AssignRoomId,
                    CustomerAddress = objBookingViewModel.CustomerAddress,
                    CustomerName = objBookingViewModel.CustomerName,
                    NoOfMembers = objBookingViewModel.NumberOfMembers,
                    TotalAmount = totalPrice
                };

                objMTLDBEntities1.RoomBookings.Add(roomBooking);
                objMTLDBEntities1.SaveChanges();

                objRoom.BookingStatusId = 3;
                objMTLDBEntities1.SaveChanges();

                return Json(new { message = "Hotel Reservation is Successfully done.", success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = "An error occurred: " + ex.Message, success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public PartialViewResult GetAllBookingHistory()
        {
            List<RoomBookingViewModel> listOfBookingViewModels = new List<RoomBookingViewModel>();

            listOfBookingViewModels = (from objHotelBooking in objMTLDBEntities1.RoomBookings
                                       join objRoom in objMTLDBEntities1.Rooms on objHotelBooking.AssignRoomId equals objRoom.RoomId
                                       select new RoomBookingViewModel()
                                       {
                                           BookingFrom = objHotelBooking.BookingFrom,
                                           BookingTo = objHotelBooking.BookingTo,
                                           CustomerName = objHotelBooking.CustomerName,
                                           CustomerAddress = objHotelBooking.CustomerAddress,
                                           TotalAmount = objHotelBooking.TotalAmount,
                                           NumberOfMembers = objHotelBooking.NoOfMembers,
                                           BookingId = objHotelBooking.BookingId,
                                           RoomNumber = objRoom.RoomNumber.ToString(),
                                           RoomPrice = objRoom.RoomPrice,
                                           NumberOfDays = System.Data.Entity.DbFunctions.DiffDays(objHotelBooking.BookingFrom, objHotelBooking.BookingTo).Value
                                       }).ToList();

            return PartialView("_BookingHistoryPartial", listOfBookingViewModels);
        }

        [HttpPost]
        public JsonResult DeleteBooking(int bookingId)
        {
            try
            {
                var booking = objMTLDBEntities1.RoomBookings.SingleOrDefault(b => b.BookingId == bookingId);
                if (booking == null)
                {
                    return Json(new { message = "Booking not found.", success = false }, JsonRequestBehavior.AllowGet);
                }

                var room = objMTLDBEntities1.Rooms.SingleOrDefault(r => r.RoomId == booking.AssignRoomId);
                if (room != null)
                {
                    room.BookingStatusId = 2; 
                }

                objMTLDBEntities1.RoomBookings.Remove(booking);
                objMTLDBEntities1.SaveChanges();

                return Json(new { message = "Booking deleted successfully.", success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { message = "An error occurred: " + ex.Message, success = false }, JsonRequestBehavior.AllowGet);
            }
        }
    }
}
