﻿namespace WebApplication3Updated.Controllers
{
    internal class ctor
    {
    }
}