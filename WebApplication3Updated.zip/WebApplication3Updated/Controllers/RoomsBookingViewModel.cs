﻿namespace WebApplication3Updated.Controllers
{
    internal class RoomsBookingViewModel
    {
    }
}