﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication3Updated.Models;
using WebApplication3Updated.ViewModel;

namespace WebApplication3Updated.Controllers
{
    public class RoomController : Controller
    {
        private MTLDBEntities1 objMTLDBEntities1;
        public object objRoom;

        public RoomController()
        {
            objMTLDBEntities1 = new MTLDBEntities1();
        }

        

        public ActionResult Index()
        {
            RoomViewModel objRoomViewModel = new RoomViewModel();

            objRoomViewModel.ListOfBookingStatus = (from obj in objMTLDBEntities1.BookingStatus
                                                    select new SelectListItem()
                                                    {
                                                        Text = obj.BookingStatus,
                                                        Value = obj.BookingStatusId.ToString()
                                                    }).ToList();

            objRoomViewModel.ListOfRoomType = (from obj in objMTLDBEntities1.RoomTypes
                                               select new SelectListItem()
                                               {
                                                   Text = obj.RoomTypeName,  
                                                   Value = obj.RoomTypeId.ToString()
                                               }).ToList();

            return View(objRoomViewModel);
        }
        [HttpPost]
        
        public ActionResult Index(RoomViewModel objRoomViewModel)
        {
            string message = String.Empty;
            string ImageUniqueName = String.Empty;
            string ActualImageName = String.Empty;

            //Method To Update the room!!!

            // Check if RoomId exists for update
            if (objRoomViewModel.RoomId != 0)
            {
                Room objRoom = objMTLDBEntities1.Rooms.SingleOrDefault(model => model.RoomId == objRoomViewModel.RoomId);

                if (objRoom != null) // Room found for update
                {
                    if (objRoomViewModel.Image != null) // Update image if provided
                    {
                        // Generate unique image name
                        ImageUniqueName = Guid.NewGuid().ToString();
                        ActualImageName = ImageUniqueName + Path.GetExtension(objRoomViewModel.Image.FileName);

                        // Save the uploaded image
                        objRoomViewModel.Image.SaveAs(Server.MapPath("~/RoomImages/" + ActualImageName));

                        // Update the RoomImage property
                        objRoom.RoomImage = ActualImageName;
                    }

                    // Update other room properties
                    objRoom.RoomNumber = Convert.ToInt32(objRoomViewModel.RoomNumber);
                    objRoom.RoomDescription = objRoomViewModel.RoomDescription;
                    objRoom.RoomPrice = objRoomViewModel.RoomPrice;
                    objRoom.BookingStatusId = objRoomViewModel.BookingStatusId;
                    objRoom.RoomCapacity = objRoomViewModel.RoomCapacity;
                    objRoom.RoomTypeId = objRoomViewModel.RoomTypeId;

                    message = "Updated.";
                }
                else
                {
                    // Room not found for update (handle error if needed)
                    message = "Error: Room not found.";
                    return Json(new { message = message, success = false }, JsonRequestBehavior.AllowGet);
                }
            }

            //Entering a new room in the database while using the frontend!!!
            else // New room
            {
                // Convert RoomNumber to integer for comparison
                int roomNumber = Convert.ToInt32(objRoomViewModel.RoomNumber);

                // Check for duplicate room number
                bool isRoomNumberExists = objMTLDBEntities1.Rooms.Any(r => r.RoomNumber == roomNumber);
                if (isRoomNumberExists)
                {
                    message = "Error: Room number already exists.";
                    return Json(new { message = message, success = false }, JsonRequestBehavior.AllowGet);
                }

                // Generate unique image name
                ImageUniqueName = Guid.NewGuid().ToString();
                ActualImageName = ImageUniqueName + Path.GetExtension(objRoomViewModel.Image.FileName);
                objRoomViewModel.Image.SaveAs(Server.MapPath("~/RoomImages/" + ActualImageName));

                Room objRoom = new Room()
                {
                    RoomNumber = roomNumber,
                    RoomDescription = objRoomViewModel.RoomDescription,
                    RoomPrice = objRoomViewModel.RoomPrice,
                    BookingStatusId = objRoomViewModel.BookingStatusId,
                    IsActive = true,
                    RoomImage = ActualImageName,
                    RoomCapacity = objRoomViewModel.RoomCapacity,
                    RoomTypeId = objRoomViewModel.RoomTypeId
                };
                objMTLDBEntities1.Rooms.Add(objRoom);
                message = "Added.";
            }

            objMTLDBEntities1.SaveChanges();

            return Json(new { message = "Room " + message + " Successfully.", success = true }, JsonRequestBehavior.AllowGet);
        }


        public PartialViewResult GetAllRooms()
        {
            var listOfroomDetailsViewModels =
                (from objRoom in objMTLDBEntities1.Rooms
                 join objBooking in objMTLDBEntities1.BookingStatus on objRoom.BookingStatusId equals objBooking.BookingStatusId
                 join objRoomType in objMTLDBEntities1.RoomTypes on objRoom.RoomTypeId equals objRoomType.RoomTypeId
                 where objRoom.IsActive == true
                 select new RoomDetailsViewModel()
                 {
                     RoomNumber = objRoom.RoomNumber.ToString(), // Convert here
             RoomDescription = objRoom.RoomDescription,
                     RoomCapacity = objRoom.RoomCapacity,
                     RoomPrice = objRoom.RoomPrice,
                     BookingStatus = objBooking.BookingStatus,
                     RoomType = objRoomType.RoomTypeName,
                     RoomImage = objRoom.RoomImage,
                     RoomId = objRoom.RoomId
                 }).ToList();

            return PartialView("_RoomDetailsPartial", listOfroomDetailsViewModels);
        }

        [HttpGet]
        public JsonResult EditRoomDetails(int roomId)
        {
            try
            {
                var room = objMTLDBEntities1.Rooms.SingleOrDefault(model => model.RoomId == roomId);
                if (room != null)
                {
                    return Json(new
                    {
                        success = true,
                        Room = new
                        {
                            room.RoomId,
                            room.RoomNumber,
                            room.RoomPrice,
                            room.BookingStatusId,
                            room.RoomTypeId,
                            room.RoomCapacity,
                            room.RoomDescription,
                            room.RoomImage
                        }
                    }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { success = false, message = "Room not found." }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                // Log the exception for debugging
                Console.WriteLine(ex.Message);
                return Json(new { success = false, message = "An error occurred while fetching the room details." }, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpPost]
        public JsonResult UpdateRoomDetails(Room updatedRoom)
        {
            try
            {
                var room = objMTLDBEntities1.Rooms.SingleOrDefault(model => model.RoomId == updatedRoom.RoomId);
                if (room != null)
                {
                    room.RoomNumber = updatedRoom.RoomNumber;
                    room.RoomPrice = updatedRoom.RoomPrice;
                    room.BookingStatusId = updatedRoom.BookingStatusId;
                    room.RoomTypeId = updatedRoom.RoomTypeId;
                    room.RoomCapacity = updatedRoom.RoomCapacity;
                    room.RoomDescription = updatedRoom.RoomDescription;
                    room.RoomImage = updatedRoom.RoomImage;
                    objMTLDBEntities1.SaveChanges();

                    return Json(new { success = true, message = "Room details updated successfully." });
                }
                else
                {
                    return Json(new { success = false, message = "Room not found." });
                }
            }
            catch (Exception ex)
            {
                // Log the exception for debugging
                Console.WriteLine(ex.Message);
                return Json(new { success = false, message = "An error occurred while updating the room details." });
            }
        }

        [HttpPost]
        public JsonResult DeleteAllRooms(int roomId)
        {
            try
            {
                Room objRoom = objMTLDBEntities1.Rooms.SingleOrDefault(model => model.RoomId == roomId);
                if (objRoom != null)
                {
                    objRoom.IsActive = false;
                    objMTLDBEntities1.SaveChanges();
                    return Json(new { message = "Record Deleted Successfully.", success = true });
                }
                else
                {
                    return Json(new { message = "Room not found.", success = false });
                }
            }
            catch (Exception ex)
            {
                // Log the exception for debugging purposes
                Console.WriteLine(ex.Message);
                return Json(new { message = "An error occurred while deleting the record.", success = false });
            }
        }

    }
}