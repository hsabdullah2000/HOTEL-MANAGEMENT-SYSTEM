﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace WebApplication3Updated.ViewModel
{
    public class BookingViewModel
    {
        [Display(Name = "Customer Name: ")]
        public string CustomerName { get; set; }

        [Display(Name = "Customer Address: ")]
        public string CustomerAddress { get; set; }

        [Display(Name = "Booking From: ")]
        [Required(ErrorMessage = "Booking From is required.")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime BookingFrom { get; set; }

        [Display(Name = "Booking To: ")]
        [Required(ErrorMessage = "Booking To is required.")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime BookingTo { get; set; }

        [Display(Name = "Assign Room: ")]
        [Required(ErrorMessage = "Room is required.")]
        public int AssignRoomId { get; set; }

        [Display(Name = "Number Of Members: ")]
        public int NumberOfMembers { get; set; }

        public IEnumerable<SelectListItem> ListOfRooms { get; set; }
    }
}
